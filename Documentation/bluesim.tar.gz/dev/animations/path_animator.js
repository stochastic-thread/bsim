
var DEBUG_HOVER = false;
var entityPath = [];
function runPathFlowAnimation() {
	
	console.log("ANIMATION: started");
	// $("#accordion").hide();
	document.getElementById("color_key").style.visibility = "visible";
	d3.select("#accordion")
		.transition().duration(1000)
		.style("opacity", 0).each("end", function() {	
   			d3.select("#color_key").transition().duration(1000).style("opacity", 1);
		});
	

	var colorSpeed = {					// can shoose speeds for the simulation colors
		red:1,
		orange:2,
		yellow:3,
		blue:4,
		green:5
	}

	// preferences
	var STROKE_DASH 	= "3,9 3,9";
	var STROKE_COLOR 	= "#2980b9";  		// we can also randomize colors
	var STROKE_WIDTH 	= "6";
	var STROKE_OPACITY 	= "0.5";		// or do something with opacity
	var STROKE_LINECAP 	= "round";
	var DIRECTION 		= -1;			// (<-- 1) (--> -1) 		

	var paths = [];
	var images = [];

	var svg = document.getElementById("canvas").children[0];
	svg.id = "svg"; 					// assign id to svg
	
	var pathIds = 0; 					// assign ids to paths		
	

	for (var i = 0; i < svg.children.length; i++) {
		var currElmt = svg.children[i];
		
		if (currElmt.nodeName.toLowerCase() === "path" 
			&& currElmt.hasAttribute("stroke-width")) {					// filtering elements in svg - we only want paths

			var strokeVal = currElmt.getAttribute("stroke-width");		// this is the only way to identify paths
			if (strokeVal === "3") {

				currElmt.id = "path" + pathIds++;

				var dataFrom = currElmt.getAttribute("data-from");
				var dataTo = currElmt.getAttribute("data-to");

				var fromEnt;
				var toEnt;

				for (var k = 0;k<QueueApp.models.length;k++){
					if (QueueApp.models[k].view.id == dataFrom){
						fromEnt = QueueApp.models[k];
					} else if (QueueApp.models[k].view.id == dataTo) {
						toEnt = QueueApp.models[k];
					}
				}
				var temp = [fromEnt, toEnt];
				entityPath.push(temp);
				//special case for split function
					// console.log(fromEnt.view.id + "  " + toEnt.view.id);
				if (/^splitfunc/.test(fromEnt.view.id)){
					
//////////////////////////////////////////////////////////////////////////////////////////
//			HARD CODED:				WILL NEED TO BE CALCULATED BASED ON TRAFFIC FLOW BETWEEN THE TWO
					
/////////////////////////////////////////////////////////////////////////////////////////
					// if toEnt is dist1 assign path colorUp
					if (toEnt.view.id == fromEnt.dest[0].view.id){
                        
                        if ((/^thermometer/.test(dataTo)) || (/^reverser/.test(dataTo)) || (/^func/.test(dataTo))  ){
                            if (toEnt.view.color != undefined){
                                toEnt.view.color = colorSpeed[fromEnt.view.colorUp] > colorSpeed[toEnt.view.color] ? fromEnt.view.colorUp : toEnt.view.color;
                            } else {
                                toEnt.view.color = fromEnt.view.colorUp;
                            }
                            // console.log(" color up:+++ "  + toEnt.view.id +  " color " + toEnt.view.color);
                        }
                        
                        // currElmt.style['stroke'] = fromEnt.view.colorUp;
                        currElmt.name = colorSpeed[fromEnt.view.colorUp];
                        
                    } else {

                        if ((/^thermometer/.test(dataTo)) || (/^reverser/.test(dataTo)) || (/^func/.test(dataTo))  ){
                            if (toEnt.view.color != undefined){
                                toEnt.view.color = colorSpeed[fromEnt.view.colorDown] > colorSpeed[toEnt.view.color] ? fromEnt.view.colorDown : toEnt.view.color;
                            } else {
                                toEnt.view.color = fromEnt.view.colorDown;
                            }
                            // console.log("color down: ++ " + toEnt.view.id +  " color " + toEnt.view.color);
                        }
                    
                        // currElmt.style['stroke'] = fromEnt.view.colorDown;
                        currElmt.name = colorSpeed[fromEnt.view.colorDown];
                    }


                } 
                //case where we are using anything else
                else {
                    if (fromEnt.view.color != undefined){
                        // currElmt.style['stroke'] = fromEnt.view.color;
                    }
                    currElmt.name = colorSpeed[fromEnt.view.color];

                    if ((/^thermometer/.test(dataTo)) || (/^reverser/.test(dataTo)) || (/^func/.test(dataTo))  ){
                        
                        if (toEnt.view.color != undefined){
                            toEnt.view.color = colorSpeed[fromEnt.view.color] > colorSpeed[toEnt.view.color] ? fromEnt.view.color : toEnt.view.color;
                        } else {
                            toEnt.view.color = fromEnt.view.color;
                        }
                        // console.log("color :: ++ " + toEnt.view.id +  " color " + toEnt.view.color);
                        currElmt.name = colorSpeed[fromEnt.view.color];
                    }
                }

				paths.push(currElmt);
				
			} 
		} else if (currElmt.nodeName.toLowerCase() === "a") {
			 if (currElmt.children[0] != null) {
				if (currElmt.children[0]["id"].endsWith("img")) {
					// going through entity icons
					images.push(currElmt.children[0]);
				}
 			 }
		}
	}
		var Hover = {
		start: function() {
			oo = this;
			for (var i = 0; i < images.length; i++) {
				var img = images[i];
				img.onmouseover = function() {
					oo.renderForm(this);
					$('#hover_form').show().position({
						of: this,
						at: "right+80 top-25%",
						my: "left top"
					});
				}
				img.onmouseout = function() {
					$('#hover_form_to_append table').empty();
					$('#hover_form').hide();
				}
			}
		},
		// kill_form: function() {
		// 			$('#hover_form_to_append').empty();
		// 			$('#hover_form_to_append').append("<table class='table table-bordered'></table>");
		// 			$('#hover_form').hide();
		// },
		similar: function(obj) {
			var max = 0;
			for (key in obj) {
				if (obj.hasOwnProperty(key)){ 
					if (obj[key] > max) {
						max = obj[key];
					}
				}
			}
			var list = [];
			for (var i=0; i<max;i+=1) {
				list.push(null);
			}

			for (key in obj) {
				if (obj.hasOwnProperty(key)){ 
					if (list[obj[key]] == null) {
						list[obj[key]] = [];
						list[obj[key]].push(key); 
					}
					else {
						list[obj[key]].push(key); 	
					}
				};
			};
			var qq = [];
			for (var i = 0; i < list.length; i+= 1) {
				if (list[i] != null) {
					// if (DEBUG_HOVER) console.log(i + " " + list[i]);
					qq.push([i, [list[i]]])
				}
			}
			// if (DEBUG_HOVER) console.log(qq);
			return qq;
		},
		renderForm: function(obj) {
			// this.kill_form();
			// console.log("Test");
			for (var i = 0; i < QueueApp.models.length; i++) {
				mdl = QueueApp.models[i];
				mdl.stat.pop;
				mdl.stat.time;
				table =	$("#hover_form_to_append table");

				if (mdl.view.id == obj.id) {
					if (mdl.view.type == "source") {
						table.append('<tr style="font-size: 12px;"><td>spawned</td><td>'+mdl.stat.spawn+'</td></tr>');
					}

					/* Queue hover */
					if (mdl.view.type == "queue") {
						// if (DEBUG_HOVER) console.log(mdl.stat);
						var obj = {};
						obj.arrived = mdl.stat.arrived;
						obj.dropped = mdl.stat.dropped;
						var qpop = mdl.stat.queue.pop;
						var qtime = mdl.stat.queue.time;
						var syspop = mdl.stat.system.pop;
						var systime = mdl.stat.system.time;
						// table.append('<tr style="font-size: 12px;"><td>Arrived</td><td>'+obj.arrived+'</td></tr>');
						// table.append('<tr style="font-size: 12px;"><td>Arrived</td><td>'+obj.dropped+'</td></tr>');
						for (var key in qpop) {
					    if (qpop.hasOwnProperty(key)) {
					    	var thing = qpop[key];
					    	if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
					    		obj['queue population series ' + key.toLowerCase()] = thing;
									// table.append('<tr style="font-size: 12px;"><td>Queue Population Series '+key+'</td><td>'+thing+'</td></tr>');
					    	}
					    }
						}
						for (var key in qtime) {
					    if (qtime.hasOwnProperty(key)) {
					    	var thing = qtime[key];
					    	if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
					    		obj['queue time series ' + key.toLowerCase()] = thing;
									// table.append('<tr style="font-size: 12px;"><td>Queue Time Series '+key+'</td><td>'+thing+'</td></tr>');
					    	}
					    }
						}
						for (var key in syspop) {
					    if (syspop.hasOwnProperty(key)) {
					    	var thing = syspop[key];
					    	if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
					    		obj['system population series ' + key.toLowerCase()] = thing;
									// table.append('<tr style="font-size: 12px;"><td>System Population Series '+key+'</td><td>'+thing+'</td></tr>');
					    	}
					    }
						}
						for (var key in systime) {
					    if (systime.hasOwnProperty(key)) {
					    	var thing = systime[key];
					    	if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
					    		obj['system time series ' + key.toLowerCase()] = thing;
									// table.append('<tr style="font-size: 12px;"><td>System Time Series '+key+'</td><td>'+thing+'</td></tr>');
					    	}
					    }
						}
						var lists = this.similar(obj);
						var vals = [];
						var strs = [];
						for (var i = 0; i < lists.length; i += 1) {
							vals.push(lists[i][0]);
							strs.push(lists[i][1]);
						}

						for (var j = 0; j < strs.length; j += 1) {
							var str = "";
							for (var k = 0; k < strs[j][0].length; k += 1) {
								if (j == strs[j][0].length - 1) {
									str += ('<span>'+strs[j][0][k]+'</span></br>')
								}
								else {
									str += ('<span>'+strs[j][0][k]+'</span></br>');
								}
							}
							// console.log(str);
							// if (DEBUG_HOVER) console.log(str);
							strs[j] = str;
							table.append('<tr style="font-size: 12px;"><td>'+str+'</td><td>'+vals[j]+'</td></tr>');
							// console.log(strs[j] + " " + vals[j]);
						}
					} /* Queue hover OVER */

					/* Sink hover */
					if (mdl.view.type == "sink") {
						// if (DEBUG_HOVER) console.log("SINK TEST");
						var obj = {};
						var pop = mdl.stat.pop;
						var time = mdl.stat.time;

						for (var key in mdl.stat.pop) {
					    if (mdl.stat.pop.hasOwnProperty(key)) {
					    	var thing = mdl.stat.pop[key];
					    	if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
					    		obj['population series ' + key.toLowerCase()] = thing;
					    	}
					    }
						}
						for (var key in mdl.stat.time) {

							if (mdl.stat.time.hasOwnProperty(key)) {
								var thing = mdl.stat.time[key];
								if (thing != undefined && thing != 0 && !isNaN(thing) && thing != Infinity && thing != -Infinity) {
									if (key === "W") {
										obj['time series weight '] = thing;
									}
									else {
										// if (DEBUG_HOVER) console.log(key);
										obj['time series ' + key.toLowerCase()] = thing;
									}
								}
							}
						}
						var lists = this.similar(obj);
						var vals = [];
						var strs = [];
						for (var i = 0; i < lists.length; i += 1) {
							vals.push(lists[i][0]);
							strs.push(lists[i][1]);
						}

						for (var j = 0; j < strs.length; j += 1) {
							var str = "";
							for (var k = 0; k < strs[j][0].length; k += 1) {
								if (j == strs[j][0].length - 1) {
									str += ('<span>'+strs[j][0][k]+'</span></br>');
								}
								else {
									str += ('<span>'+strs[j][0][k]+'</span></br>');
								}
							}
							// console.log(str);
							// if (DEBUG_HOVER) console.log(str);
							strs[j] = str;
							table.append('<tr style="font-size: 12px;"><td>'+str+'</td><td>'+vals[j]+'</td></tr>');
						}
					}
				}
			}
		}
	};
	Hover.start();

	function runAnimations(path, speed) {
		// console.log(speed);
		var p = d3.select("#" + path.id);
		// fade out
	    p.transition().duration(800)
	    	.style("opacity", 0)
	    	.each("end", function() { 
	    		path.style['stroke-dasharray']	= STROKE_DASH;
				// path.style['stroke-opacity'] 	= STROKE_OPACITY;
				path.style["stroke-linecap"] 	= STROKE_LINECAP;
				path.style['stroke-width'] 		= STROKE_WIDTH;

	    		animatePathFlow(path, speed)
	    	} );
	}

	function animatePathFlow(path, speed) {
		//console.log(path + " " + " speed " + speed);
		var iScale = 1; 		// increase for longer time
		var nIterations = 0;
		var msec = 0.5;			// time interval
		switch(speed) {
			case 5: nIterations = 400 * iScale;
				msec = 25;
				path.style["stroke"] = "#27ae60"; /* green */
				break;
			case 4:
				nIterations = 200 * iScale;
				msec = 50;
				path.style["stroke"] = "#2980b9"; /* pastel blue */
				break;
			case 3:
				nIterations = 100 * iScale;
				msec = 100;
				path.style["stroke"] = "#f1c40f"; /* sunflower yellow */
				break;
			case 2:
				nIterations = 50 * iScale;
				msec = 200;
				path.style["stroke"] = "#e67e22"; /* carrot orange */
				break;
			case 1:
				nIterations = 25 * iScale;
				msec = 400;
				path.style["stroke"] = "#c0392b"; /* red */
				break;
			default:
				var dataFrom = path.getAttribute("data-from")
				// console.log(dataFrom);
				var entSpeed  = 1;

				for (var i = 0;i < entityPath.length;i++){
					// console.log(entityPath[i]);
					if (entityPath[i][1].view.id == dataFrom){
						if (entityPath[i][1].view.color != undefined){
							entSpeed = colorSpeed[entityPath[i][1].view.color];
						} else {
							entSpeed = colorSpeed[entityPath[i][0].view.color];
						}
					}
				}
				animatePathFlow(path, entSpeed);
				return;
				break;
		}

		// fade in
		var p = d3.select("#" + path.id);
		p.transition().duration(1000).style("opacity", 0.5)
	    			.each("end", function(){
	    				// path flow animation
	    				// animatePathFlow(path, speed);
	    });

		var c = 1;

		function loop(c) {
			setTimeout(function () { 

				path.style['stroke-dashoffset'] = c * DIRECTION;
				if (c < 0) {
					loop(c+1)
				} else {
					if (path["id"] === "path"+(paths.length-1)) {
						console.log("ANIMATION: ended");
						restorePaths();
						SIM_HAS_RUN = true;
						SIM_IS_RUNNING = false;
						d3.select("#color_key").transition().duration(1000)
							.style("opacity", 0).each("end", function() {
								d3.select("#accordion").transition().duration(1000).style("opacity", 1);
							})
					}
				}
			}, msec)
		}

		loop(-nIterations); // fixes problem with Firefox
	}

	function restorePaths() {
		for (var i = 0; i < paths.length; i++) {
			paths[i].style['stroke-dasharray'] = "";	
			paths[i].style['stroke-opacity'] 	= "1";	
			paths[i].style['stroke-width'] 		= "3";	
			paths[i].style['stroke'] 			= "#3498db";
		}
	}

	for (var i = 0; i < paths.length; i++) {

		runAnimations(paths[i], paths[i].name); 
		// console.log(paths[i].name);
		
	}
}







