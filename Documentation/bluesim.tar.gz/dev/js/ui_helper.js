// renames entities
function rename(entity, labelID) {
    var label = document.getElementById(labelID).value;  
   if (label !== "") {

      for (var i = 0; i < QueueApp.models.length;i++){
        if (QueueApp.models[i] != entity &&  QueueApp.models[i].view.username == label){
            bootbox.alert("<strong><font size='3'>Name already used.  Please enter unique name</font></strong>");
            return;
        }
      }

       entity.view["username"] = label; 
        entity.view.image.node.parentNode.nextSibling.children[0].innerHTML = label;
    }
}

function displayName(entity, labelID) {
    // retrieve and display durrent name in popup
   document.getElementById(labelID).value = entity.view["username"];

}

